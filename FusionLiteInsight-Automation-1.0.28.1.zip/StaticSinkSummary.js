print("Static Sink Summary");

var args = arguments;

function extension()
{
    return false;
}

function start(type)
{
    load(directory + "/" + "Core.js");
    load(directory + "/" + "StaticSink.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            if (structureFile())
            {
                var fileName = "Temp" + ".txt";

                var filePath = "../Temp/" + fileName;

                var PrintStream = Java.type("java.io.PrintStream");

                var printStream = new PrintStream(filePath);

                print = function(value)
                {
                    printStream.println(value);
                }

                structure();

                printStream.close();
            }
            else
            {
                structure();
            }
        }
    }

    return false;
}

function structure()
{
    analyze();
}

function analyze()
{
    var analysisItems = interfazeProcessor.getAnalysisItems();

    analysisItems = processStructureItems(analysisItems);

    if (analysisItems != null)
    {
        printStructureItems(analysisItems);
    }
}

function processStructureItems(analysisItems)
{
    if (analysisItems != null)
    {
        var structureItems = [];

        for (var i=0; i<analysisItems.length; i++)
        {
            var analysisItem = analysisItems[i];

            analysisItem = processStructureItem(analysisItem);

            if (analysisItem != null)
            {
                structureItems.push(analysisItem);
            }
        }

        if (structureItems.length != 0)
        {
            return structureItems;
        }

        return null;
    }

    return null;
}

function processStructureItem(analysisItem)
{
    var category = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    category = sinkProcess(category, color, analysisItem);

    if (category != null)
    {
        analysisItem.setText(category);

        return analysisItem;
    }

    return null;
}

function trimItem(item)
{
    var HashSet = Java.type("java.util.HashSet");

    var set = new HashSet();

    var children = item.children;

    if (children != null && !isLeaf(item))
    {
        var ArrayList = Java.type("java.util.ArrayList");

        var list = new ArrayList();

        for (var i=0; i<children.length; i++)
        {
            var child = children[i];

            var duplicate = compactItem(child, set);

            if (!duplicate)
            {
                list.add(child);
            }
        }

        var ItemArray = Java.type("fusionlite.model.Analysis.AdvancedItem[]");

        children = list.toArray(new ItemArray(0));

        item.children = children;

        if (children.length != 0)
        {
        }
    }
}

function compactItem(item, set)
{
    var children = item.children;

    if (children != null && !isLeaf(item))
    {
        var ArrayList = Java.type("java.util.ArrayList");

        var list = new ArrayList();

        for (var i=0; i<children.length; i++)
        {
            var child = children[i];

            var duplicate = compactItem(child, set);

            if (!duplicate)
            {
                list.add(child);
            }
        }

        var ItemArray = Java.type("fusionlite.model.Analysis.AdvancedItem[]");

        children = list.toArray(new ItemArray(0));

        item.children = children;

        if (children.length != 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return isTrim(item, set);
    }
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "category"             :   return "\u001B[38;5;141m";
            case "signature_green"      :   return "\u001B[38;5;77m";
            case "signature_orange"     :   return "\u001B[38;5;208m";
            case "signature_red"        :   return "\u001B[38;5;196m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
