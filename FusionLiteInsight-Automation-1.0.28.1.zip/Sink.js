function getReverseItems(processor, points)
{
    if (processor.isAnalysisReverse())
    {
        return processor.getAnalysisReverseItems(points);
    }

    return null;
}

function printReverseItems(analysisItems, points)
{
    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printReverseItem(analysisItems[i], 0, points);
        }

        print("");
    }
}

function printReverseItem(analysisItem, depth, points)
{
    var text = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("sink_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printReverseSink(analysisItems[i], depth + 1);
        }
    }
}

function printReverseNodes(analysisItem, depth)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printReverseNode(analysisItems[i], depth);
        }
    }
}

function printReverseNode(analysisItem, depth)
{
    var text = analysisItem.getText();

    if (text.startsWith("Transform" + " "))
    {
        printReverseTransform(analysisItem, depth);
    }
    else if (text.startsWith("Indirect" + " "))
    {
        printReverseIndirect(analysisItem, depth);
    }
    else if (text.startsWith("Source" + " "))
    {
        printReverseSource(analysisItem, depth);
    }
    else if (text == "Unknown" || text.startsWith("Unknown" + " "))
    {
        printReverseUnknown(analysisItem, depth);
    }
    else if (text.startsWith("Constant" + " "))
    {
        printReverseConstant(analysisItem, depth);
    }
    else if (text == "Composite")
    {
        printReverseComposite(analysisItem, depth);
    }
    else if (text == "Tracked")
    {
        printReverseTracked(analysisItem, depth);
    }
    else if (text == "Tracking")
    {
        printReverseTracking(analysisItem, depth);
    }
    else if (text == "Untracked" || text.startsWith("Untracked" + " "))
    {
        printReverseUntracked(analysisItem, depth);
    }
    else if (text == "Completed")
    {
        printReverseCompleted(analysisItem, depth);
    }
    else if (text == "Element <- Array")
    {
        printReverseNodes(analysisItem, depth);
    }
    else if (text == "Array <- Element")
    {
        printReverseNodes(analysisItem, depth);
    }
    else
    {
        if (isReverseCategory(text))
        {
            if (text != "FX")
            {
                if (text != "RETURN")
                {
                    var Color = Java.type("fusionlite.model.Color");

                    var color = Color.color(Color.combine(analysisItem.getColor()));

                    print(pad(depth) + style_static("source_" + color) + display(text) + style_static(null));

                    printReverseNodes(analysisItem, depth + 1);
                }
                else
                {
                    var filter = analysisItem.getFilter();

                    if (filter != -1)
                    {
                        var Color = Java.type("fusionlite.model.Color");

                        var color = Color.color(Color.combine(analysisItem.getColor()));

                        print(pad(depth) + style_static("return_" + color) + display(text) + style_static(null));

                        var analysisItems = analysisItem.getChildren();

                        if (analysisItems != null)
                        {
                            for (var i=0; i<analysisItems.length; i++)
                            {
                                printReverseReturn(analysisItems[i], depth + 1);
                            }
                        }
                    }
                }
            }
            else
                printReverseNodes(analysisItem, depth);
        }
        else
            printReverseNodes(analysisItem, depth);
    }
}

function isReverseCategory(str)
{
    for (var i=0; i<str.length; i++)
    {
        var character = str.charAt(i);

        if (character != character.toUpperCase())
        {
            return false;
        }
    }

    return true;
}

function printReverseSink(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Sink" + " ").length);

    text = "Sink" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("sink_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("sink_" + attributeColor) + display(attributeText) + style_static(null));

                print(pad(depth + 2) + style_static("sink_" + attributeColor) + display("...") + style_static(null));

                printReverseNodes(analysisItems[i], depth + 3);
            }
        }
    }
}

function printReverseTransform(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Transform" + " ").length);

    text = "Transform" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " ") || attribute.startsWith("Return" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                printReverseNodes(analysisItems[i], depth);
            }
        }
    }
}

function printReverseIndirect(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Indirect" + " ").length);

    text = "Indirect" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                printReverseNodes(analysisItems[i], depth);
            }
        }
    }
}

function printReverseSource(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Source" + " ").length);

    text = "Source" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("source_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " ") || attribute.startsWith("Return" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("source_" + attributeColor) + display(attributeText) + style_static(null));
            }
        }
    }
}

function printReverseReturn(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Unknown" + " ").length);

    text = "Other" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("return_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Return" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("return_" + attributeColor) + display(attributeText) + style_static(null));
            }
        }
    }
}

function printReverseUnknown(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Unknown" + " "))
    {
        signature = text.substring(("Unknown" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    if (signature != null)
    {
        print(pad(depth) + style_static("unknown") + display(text) + style_static(null));
    }
}

function printReverseConstant(analysisItem, depth)
{
    var text = analysisItem.getText();

    var value = text.substring(("Constant" + " ").length);

    text = "\"" + value + "\"";

    // print(pad(depth) + style_static("constant") + display(text) + style_static(null));
}

function printReverseComposite(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("composite") + display(text) + style_static(null));
}

function printReverseTracked(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("tracked") + display(text) + style_static(null));
}

function printReverseTracking(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("tracking") + display(text) + style_static(null));
}

function printReverseUntracked(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Untracked" + " "))
    {
        signature = text.substring(("Untracked" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    if (signature != null)
    {
        print(pad(depth) + style_static("untracked") + display(text) + style_static(null));
    }
}

function printReverseCompleted(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("completed") + display(text) + style_static(null));
}

function style_static(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "sink_green"       :   return "\u001B[38;5;77m";
            case "sink_orange"      :   return "\u001B[38;5;208m";
            case "sink_red"         :   return "\u001B[38;5;196m";
            case "source_green"     :   return "\u001B[38;5;77m";
            case "source_orange"    :   return "\u001B[38;5;202m";
            case "source_red"       :   return "\u001B[38;5;196m";
            case "return_green"     :   return "\u001B[38;5;77m";
            case "return_orange"    :   return "\u001B[38;5;202m";
            case "return_red"       :   return "\u001B[38;5;196m";
            case "return_none"      :   return "\u001B[38;5;74m";
            case "unknown"          :   return "\u001B[38;5;208m";
            case "constant"         :   return "\u001B[38;5;77m";
            case "composite"        :   return "\u001B[38;5;77m";
            case "tracked"          :   return "\u001B[38;5;73m";
            case "tracking"         :   return "\u001B[38;5;73m";
            case "untracked"        :   return "\u001B[38;5;208m";
            case "completed"        :   return "\u001B[38;5;77m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
