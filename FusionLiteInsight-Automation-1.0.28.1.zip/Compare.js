load(directory + "/" + "diff_match_patch.js");

function compare(string1, string2, range)
{
    var diff = new diff_match_patch();

    diff.Diff_Timeout = 0;

    var diffs = diff.diff_main(string1, string2);

    diff.diff_cleanupSemantic(diffs);

    var result = diffs_compare(diffs, range);

    return result;
}

function diffs_compare(diffs, range)
{
    var pre = null;

    var post = null;

    if (range != -1)
    {
        if (range != 0)
        {
            var size = diffs.length;

            var lengths = new Array(size);

            pre = new Array(size);

            post = new Array(size);

            var index = 0;

            for (var i=0; i<size; i++)
            {
                var diff = diffs[i];

                var operation = diff[0];

                var text = diff[1];

                if (operation == DIFF_EQUAL)
                {
                    lengths[index] = text.length;
                }
                else
                {
                    lengths[index] = -1;
                }

                pre[index] = -1;

                post[index] = -1;

                index++;
            }

            var offset = -1;

            for (var i=0; i<size; i++)
            {
                var length = lengths[i];

                if (length == -1)
                {
                    offset = range;
                }
                else
                {
                    if (offset != -1)
                    {
                        if (offset > length)
                        {
                            pre[i] = length;

                            offset = offset - length;
                        }
                        else
                        {
                            pre[i] = offset;

                            offset = -1;
                        }
                    }
                }
            }

            offset = -1;

            for (var i=size-1; i>=0; i--)
            {
                var length = lengths[i];

                if (length == -1)
                {
                    offset = range;
                }
                else
                {
                    if (offset != -1)
                    {
                        if (offset > length)
                        {
                            post[i] = length;

                            offset = offset - length;
                        }
                        else
                        {
                            post[i] = offset;

                            offset = -1;
                        }
                    }
                }
            }
        }
    }

    var result = "";

    var index = 0;

    var size = diffs.length;

    for (var i=0; i<size; i++)
    {
        var diff = diffs[i];

        var operation = diff[0];

        var text = diff[1];

        switch (operation)
        {
            case DIFF_EQUAL     :   if (range != -1)
                                    {
                                        if (range != 0)
                                        {
                                            if (pre[index] != -1 && post[index] != -1)
                                            {
                                                if (pre[index] + post[index] < text.length)
                                                {
                                                    result += style_compare("equal") + text.substring(0, pre[index]) + style_compare(null);
                                                    result += style_compare("space") + "..." + style_compare(null);
                                                    result += style_compare("equal") + text.substring(text.length - post[index]) + style_compare(null);
                                                }
                                                else
                                                    result += style_compare("equal") + text + style_compare(null);
                                            }
                                            else if (pre[index] != -1)
                                            {
                                                if (pre[index] < text.length)
                                                {
                                                    result += style_compare("equal") + text.substring(0, pre[index]) + style_compare(null);
                                                    result += style_compare("space") + "..." + style_compare(null);
                                                }
                                                else
                                                    result += style_compare("equal") + text + style_compare(null);
                                            }
                                            else if (post[index] != -1)
                                            {
                                                if (post[index] < text.length)
                                                {
                                                    result += style_compare("space") + "..." + style_compare(null);
                                                    result += style_compare("equal") + text.substring(text.length - post[index]) + style_compare(null);
                                                }
                                                else
                                                    result += style_compare("equal") + text + style_compare(null);
                                            }
                                        }
                                    }
                                    else
                                        result += style_compare("equal") + text + style_compare(null);
                                    break;
            case DIFF_INSERT    :   result += style_compare("insert") + text + style_compare(null);
                                    break;
            case DIFF_DELETE    :   result += style_compare("delete") + text + style_compare(null);
                                    break;
        }

        index++;
    }

    return result;
}

function style_compare(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "equal"    :   return "\u001B[38;5;38m";
            case "space"    :   return "\u001B[38;5;226m";
            case "insert"   :   return "\u001B[38;5;196m";
            case "delete"   :   return "\u001B[38;5;77m";
            default         :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
