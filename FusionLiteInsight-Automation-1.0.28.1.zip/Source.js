function getForwardItems(processor, points)
{
    if (processor.isAnalysisForward())
    {
        return processor.getAnalysisForwardItems(points);
    }

    return null;
}

function printForwardItems(analysisItems, points)
{
    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printForwardItem(analysisItems[i], 0, points);
        }

        print("");
    }
}

function printForwardItem(analysisItem, depth, points)
{
    var text = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("source_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printForwardSource(analysisItems[i], depth + 1);
        }
    }
}

function printForwardNodes(analysisItem, depth)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printForwardNode(analysisItems[i], depth);
        }
    }
}

function printForwardNode(analysisItem, depth)
{
    var text = analysisItem.getText();

    if (text.startsWith("Transform" + " "))
    {
        printForwardTransform(analysisItem, depth);
    }
    else if (text.startsWith("Indirect" + " "))
    {
        printForwardIndirect(analysisItem, depth);
    }
    else if (text.startsWith("Sink" + " "))
    {
        printForwardSink(analysisItem, depth);
    }
    else if (text == "Unknown" || text.startsWith("Unknown" + " "))
    {
        printForwardUnknown(analysisItem, depth);
    }
    else if (text.startsWith("Constant" + " "))
    {
        printForwardConstant(analysisItem, depth);
    }
    else if (text == "Composite")
    {
        printForwardComposite(analysisItem, depth);
    }
    else if (text == "Tracked")
    {
        printForwardTracked(analysisItem, depth);
    }
    else if (text == "Tracking")
    {
        printForwardTracking(analysisItem, depth);
    }
    else if (text == "Untracked" || text.startsWith("Untracked" + " "))
    {
        printForwardUntracked(analysisItem, depth);
    }
    else if (text == "Completed")
    {
        printForwardCompleted(analysisItem, depth);
    }
    else if (text == "Element -> Array")
    {
        printForwardNodes(analysisItem, depth);
    }
    else if (text == "Array -> Element")
    {
        printForwardNodes(analysisItem, depth);
    }
    else
    {
        if (isForwardCategory(text))
        {
            if (text != "FX")
            {
                if (text != "CALL")
                {
                    var Color = Java.type("fusionlite.model.Color");

                    var color = Color.color(Color.combine(analysisItem.getColor()));

                    print(pad(depth) + style_static("sink_" + color) + display(text) + style_static(null));

                    printForwardNodes(analysisItem, depth + 1);
                }
                else
                {
                    var filter = analysisItem.getFilter();

                    if (filter != -1)
                    {
                        var Color = Java.type("fusionlite.model.Color");

                        var color = Color.color(Color.combine(analysisItem.getColor()));

                        print(pad(depth) + style_static("call_" + color) + display(text) + style_static(null));

                        var analysisItems = analysisItem.getChildren();

                        if (analysisItems != null)
                        {
                            for (var i=0; i<analysisItems.length; i++)
                            {
                                printForwardCall(analysisItems[i], depth + 1);
                            }
                        }
                    }
                }
            }
            else
                printForwardNodes(analysisItem, depth);
        }
        else
            printForwardNodes(analysisItem, depth);
    }
}

function isForwardCategory(str)
{
    for (var i=0; i<str.length; i++)
    {
        var character = str.charAt(i);

        if (character != character.toUpperCase())
        {
            return false;
        }
    }

    return true;
}

function printForwardSource(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Source" + " ").length);

    text = "Source" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("source_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " ") || attribute.startsWith("Return" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("source_" + attributeColor) + display(attributeText) + style_static(null));

                print(pad(depth + 2) + style_static("source_" + attributeColor) + display("...") + style_static(null));

                printForwardNodes(analysisItems[i], depth + 3);
            }
        }
    }
}

function printForwardTransform(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Transform" + " ").length);

    text = "Transform" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " ") || attribute.startsWith("Return" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                printForwardNodes(analysisItems[i], depth);
            }
        }
    }
}

function printForwardIndirect(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Indirect" + " ").length);

    text = "Indirect" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                printForwardNodes(analysisItems[i], depth);
            }
        }
    }
}

function printForwardSink(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Sink" + " ").length);

    text = "Sink" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("sink_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("sink_" + attributeColor) + display(attributeText) + style_static(null));
            }
        }
    }
}

function printForwardCall(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Unknown" + " ").length);

    text = "Other" + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("call_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Arguments" + " "))
            {
                var attributeText = analysisItems[i].getText();

                var attributeColor = Color.color(Color.combine(analysisItems[i].getColor()));

                print(pad(depth + 1) + style_static("call_" + attributeColor) + display(attributeText) + style_static(null));
            }
        }
    }
}

function printForwardUnknown(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Unknown" + " "))
    {
        signature = text.substring(("Unknown" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    if (signature != null)
    {
        print(pad(depth) + style_static("unknown") + display(text) + style_static(null));
    }
}

function printForwardConstant(analysisItem, depth)
{
    var text = analysisItem.getText();

    var value = text.substring(("Constant" + " ").length);

    text = "\"" + value + "\"";

    // print(pad(depth) + style_static("constant") + display(text) + style_static(null));
}

function printForwardComposite(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("composite") + display(text) + style_static(null));
}

function printForwardTracked(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("tracked") + display(text) + style_static(null));
}

function printForwardTracking(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("tracking") + display(text) + style_static(null));
}

function printForwardUntracked(analysisItem, depth)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Untracked" + " "))
    {
        signature = text.substring(("Untracked" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    if (signature != null)
    {
        print(pad(depth) + style_static("untracked") + display(text) + style_static(null));
    }
}

function printForwardCompleted(analysisItem, depth)
{
    var text = analysisItem.getText();

    text = "...";

    // print(pad(depth) + style_static("completed") + display(text) + style_static(null));
}

function style_static(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "source_green"     :   return "\u001B[38;5;77m";
            case "source_orange"    :   return "\u001B[38;5;202m";
            case "source_red"       :   return "\u001B[38;5;196m";
            case "sink_green"       :   return "\u001B[38;5;77m";
            case "sink_orange"      :   return "\u001B[38;5;208m";
            case "sink_red"         :   return "\u001B[38;5;196m";
            case "call_green"       :   return "\u001B[38;5;77m";
            case "call_orange"      :   return "\u001B[38;5;208m";
            case "call_red"         :   return "\u001B[38;5;202m";
            case "call_none"        :   return "\u001B[38;5;173m";
            case "unknown"          :   return "\u001B[38;5;208m";
            case "constant"         :   return "\u001B[38;5;77m";
            case "composite"        :   return "\u001B[38;5;77m";
            case "tracked"          :   return "\u001B[38;5;73m";
            case "tracking"         :   return "\u001B[38;5;73m";
            case "untracked"        :   return "\u001B[38;5;208m";
            case "completed"        :   return "\u001B[38;5;77m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
