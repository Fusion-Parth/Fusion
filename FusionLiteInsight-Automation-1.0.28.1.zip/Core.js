function pad(depth)
{
    var padding = "";
    for (var i=0; i<depth; i++)
        padding = padding + "    ";
    return padding;
}

function space(size)
{
    var spacing = "";
    for (var i=0; i<size; i++)
        spacing = spacing + " ";
    return spacing;
}

function display(str)
{
    if (str != null)
    {
        str = str.replace(/(?:\r\n|\r|\n)/g, '\u00BA');
        str = str.replace(/\u0001/g, '\u00FE');
    }
    return str;
}

function arrayEqual(array1, array2)
{
    if (array1.length == array2.length)
    {
        for (var i=0; i<array2.length; i++)
        {
            if (array1[i] != array2[i])
            {
                return false;
            }
        }

        return true;
    }

    return false;
}

function arrayDiff(array1, array2)
{
    for (var i=0; i<array2.length; i++)
    {
        if (i < array1.length)
        {
            if (array1[i] != array2[i])
            {
                return i;
            }
        }
        else
            return -1;
    }

    return -1;
}

function tabs2spaces(str)
{
    if (str != null)
        str = str.replace(/\t/g, "    ");
    return str;
}
