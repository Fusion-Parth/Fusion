print("Source Analysis");

function extension()
{
    return false;
}

function start(type)
{
    if (type != "Function")
    {
        return false;
    }

    load(directory + "/" + "Core.js");
    load(directory + "/" + "Source.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            return true;
        }
    }

    return false;
}

function delay()
{
    return 100;
}

var printStream = null;

function functions_preprocess()
{
    if (sourceFile())
    {
        var fileName = "Temp" + ".txt";

        var filePath = "../Temp/" + fileName;

        var PrintStream = Java.type("java.io.PrintStream");

        printStream = new PrintStream(filePath);

        print = function(value)
        {
            printStream.println(value);
        }
    }
    else
    {
        printStream = null;
    }

    var category = "SOURCES";

    print(style("category") + "Analyzing" + " " + display(category) + style(null));
    print("");
}

function function_process(fx, fxIndex)
{
    if ((sourceTrace() & 1) != 0)
    {
        print(style("function") + "Analyzing" + " : " + display(fx.getName()) + style(null));
        print("");
    }
}

function function_node_process(fx, fxIndex, fxNode, fxNodeIndex)
{
    if ((sourceTrace() & 2) != 0)
    {
        print(style("function_node") + "Analyzing" + " : " + display(fx.getName() + " > " + (fxNodeIndex + 1)) + style(null));
        print("");
    }
}

function function_data_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    if ((sourceTrace() & 4) != 0)
    {
        print(style("function_data") + "Analyzing" + " : " + display(fx.getName() + " > " + (fxNodeIndex + 1) + " > " + (fxDataIndex + 1)) + style(null));
        print("");
    }
}

function function_data_drive_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    var nodeValue = fxNode.getDescription();

    var dataValue = fxData.getDescription();

    analyze(nodeValue, dataValue);
}

function analyze(nodeValue, dataValue)
{
    var analysisImage = null;

    if (sourceImage())
    {
        analysisImage = interfazeProcessor.getImage(1);
    }

    if (analysisImage != null)
    {
        var UUID = Java.type("java.util.UUID");

        var fileName = "Image-" + UUID.randomUUID().toString() + ".png";

        var filePath = "../Temp/" + fileName;

        print("#" + fileName + "#");

        if (sourceFile())
        {
            var FileOutputStream = Java.type("java.io.FileOutputStream");

            var fileOutputStream = new FileOutputStream(filePath);

            fileOutputStream.write(analysisImage);

            fileOutputStream.close();
        }
    }

    analyzeSources();

    if (analysisImage != null)
    {
        print("#" + "Page" + "#");
    }
}

function initiateSourceAnalysis()
{
    if (shift)
    {
        return false;
    }

    if (interfazeProcessor.isRuntime())
    {
        return true;
    }

    return false;
}

function analyzeSource()
{
    interfazeProcessor.analyze("", 0, false, false, true, false, false, false);
}

function getAnalysisSourceItems()
{
    return getForwardItems(interfazeProcessor, false);
}

function processAnalysisSourceItems(analysisItems)
{
    if (analysisItems != null)
    {
        var sourceItems = [];

        for (var i=0; i<analysisItems.length; i++)
        {
            var analysisItem = analysisItems[i];

            analysisItem = processAnalysisSourceItem(analysisItem);

            if (analysisItem != null)
            {
                sourceItems.push(analysisItem);
            }
        }

        if (sourceItems.length != 0)
        {
            return sourceItems;
        }

        return null;
    }

    return null;
}

function processAnalysisSourceItem(analysisItem)
{
    var category = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    category = processSource(category, color, analysisItem);

    if (category != null)
    {
        analysisItem.setText(category);

        return analysisItem;
    }

    return null;
}

function printAnalysisSourceItems(analysisItems)
{
    printForwardItems(analysisItems, false);
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "category"             :   return "\u001B[38;5;141m";
            case "function"             :   return "\u001B[38;5;141m";
            case "function_node"        :   return "\u001B[38;5;141m";
            case "function_data"        :   return "\u001B[38;5;141m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}

function functions_postprocess()
{
    if (printStream != null)
    {
        printStream.close();
    }
}
