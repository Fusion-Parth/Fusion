function getHeaderValues(header)
{
    var line = header;

    var index = header.indexOf("\n");

    if (index != -1)
    {
        line = header.substring(0, index);

        index = header.indexOf("\r");

        if (index != -1)
        {
            line = header.substring(0, index);
        }
    }

    return line.split(" ");
}

function getResourceType(resource)
{
    var index = resource.indexOf("?");

    if (index != -1)
    {
        return resource.substring(0, index);
    }

    return resource;
}

function printCommunication(communication)
{
    var host = communication.getHost();

    printHost(host);

    var request = communication.getRequest();

    if (request != null)
    {
        printRequest(request);
    }

    var response = communication.getResponse();

    if (response != null)
    {
        printResponse(response);
    }
}

function printHost(host)
{
    print(style_dynamic("host") + "Host " + host + style_dynamic(null));
    print("");
}

function printRequest(request)
{
    print(style_dynamic("request") + "Request" + style_dynamic(null));
    print(style_dynamic("request") + "-------" + style_dynamic(null));

    var header = request.getHeader();
    var body = request.getBody();

    var text = style_dynamic("request_header") + header + style_dynamic(null);

    if (body != null)
        text = text + style_dynamic("request_body") + body.length + " bytes" + style_dynamic(null);

    print(text);
    print("");
}

function printResponse(response)
{
    print(style_dynamic("response") + "Response" + style_dynamic(null));
    print(style_dynamic("response") + "--------" + style_dynamic(null));

    var header = response.getHeader();
    var body = response.getBody();

    var text = style_dynamic("response_header") + header + style_dynamic(null);

    if (body != null)
        text = text + style_dynamic("response_body") + body.length + " bytes" + style_dynamic(null);

    print(text);
    print("");
}

function printError()
{
    print(style_dynamic("error") + "Error" + style_dynamic(null));
    print("");
}

function style_dynamic(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "host"             :   return "\u001B[38;5;107m";
            case "request"          :   return "\u001B[38;5;67m";
            case "request_header"   :   return "\u001B[38;5;67m";
            case "request_body"     :   return "\u001B[38;5;67m";
            case "response"         :   return "\u001B[38;5;137m";
            case "response_header"  :   return "\u001B[38;5;137m";
            case "response_body"    :   return "\u001B[38;5;137m";
            case "error"            :   return "\u001B[38;5;196m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
