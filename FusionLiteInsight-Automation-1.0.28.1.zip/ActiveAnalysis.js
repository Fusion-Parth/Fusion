print("Active Analysis");

var args = arguments;

function extension()
{
    return true;
}

function start(type)
{
    load(directory + "/" + "Core.js");
    load(directory + "/" + "Dynamic.js");
    load(directory + "/" + "Runtime.js");
    load(directory + "/" + "Compare.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            var mode = args[0];

            analyze(mode);
        }
    }

    return false;
}

function analyze(mode)
{
    if (interfazeProcessor.isRemote())
    {
        interfazeProcessor.cancelRemote();
    }

    if (mode == "Complete")
    {
        var begin = interfazeProcessor.getBegin();

        var end = interfazeProcessor.getEnd();

        for (var index=begin; index<end; index++)
        {
            analyzeCommunication(index);
        }
    }
    else if (mode == "Selected")
    {
        var selected = interfazeProcessor.getSelected();

        if (selected != -1)
        {
            analyzeSelectedCommunication(selected);
        }
    }
}

function analyzeCommunication(index)
{
    var communication = interfazeProcessor.getCommunication(index);

    if (isCommunicationAnalyzable(index, communication))
    {
        printCommunication(communication);

        var base = communication.getRef();

        var host = communication.getHost();

        var request = communication.getRequest();

        var response = communication.getResponse();

        if (request != null)
        {
            var header = request.getHeader();
            var body = request.getBody();

            analyzeHeaders(index, base, host, request, response);

            if (body != null)
            {
                analyzeContents(index, base, host, request, response);
            }
        }
    }
}

function analyzeSelectedCommunication(selected)
{
    var communication = interfazeProcessor.getCommunication(selected);

    if (isCommunicationAnalyzable(selected, communication))
    {
        printCommunication(communication);

        var base = communication.getRef();

        var host = communication.getHost();

        var request = communication.getRequest();

        var response = communication.getResponse();

        if (request != null)
        {
            var header = request.getHeader();
            var body = request.getBody();

            var REQUEST_MODE = 0;
            var RESPONSE_MODE = 1;
            var PARAMETERS_MODE = 2;
            var ANALYSIS_MODE = 3;

            var selectedMode = interfazeProcessor.getSelectedMode();

            if (selectedMode == REQUEST_MODE || selectedMode == RESPONSE_MODE)
            {
                var selection = interfazeProcessor.getSelection();

                if (selection != null)
                {
                    var mode = selection.getMode();

                    var type = selection.getType();

                    var index = selection.getIndex();

                    var length = selection.getLength();

                    var text = selection.getText();

                    if (!mode)
                    {
                        if (!type)
                        {
                            var value = header.substring(index, index + length);

                            if (value == text)
                            {
                                analyzeHeadersRegion(selected, base, host, request, response, index, length, value);
                            }
                        }
                        else
                        {
                            if (body != null)
                            {
                                var String = Java.type("java.lang.String");

                                var content = new String(body);

                                var value = content.substring(index, index + length);

                                if (value == text)
                                {
                                    analyzeContentsRegion(selected, base, host, request, response, index, length, value);
                                }
                            }
                        }
                    }
                }
            }
            else if (selectedMode == PARAMETERS_MODE)
            {
                var selectedItems = interfazeProcessor.getSelectedItems();

                if (selectedItems != null)
                {
                    var headerItems = {};

                    var contentItems = {};

                    for (var i=0; i<selectedItems.length; i++)
                    {
                        var selectedItem = selectedItems[i];

                        var type = selectedItem.getType();

                        var index = selectedItem.getIndex();

                        if (!type)
                            headerItems[index] = true;
                        else
                            contentItems[index] = true;
                    }

                    analyzeSelectedHeaders(selected, base, host, request, response, headerItems);

                    if (body != null)
                    {
                        analyzeSelectedContents(selected, base, host, request, response, contentItems);
                    }
                }
            }
        }
    }
}

function initiateParameterAnalysis(name, value)
{
    if (shift)
    {
        print(display(name) + " = " + display(value));

        return false;
    }

    if (name != null && value != null)
    {
        print(style("analyze") + "Analyzing" + " : " + display(value) + " @ " + display(name) + style(null));
        print("");

        return true;
    }

    return false;
}

function analyzeParameter(name, value)
{
    interfazeProcessor.analyze(value, 0, true, true, false, false, false, false);
}

function initiateValueAnalysis(value)
{
    if (shift)
    {
        print(display(value));

        return false;
    }

    if (value != null)
    {
        print(style("analyze") + "Analyzing" + " : " + display(value) + style(null));
        print("");

        return true;
    }

    return false;
}

function analyzeValue(value)
{
    interfazeProcessor.analyze(value, 0, true, true, false, false, false, false);
}

function getAnalysisValueItems()
{
    return getValueItems(interfazeProcessor, true);
}

function printAnalysisValueItems(analysisItems)
{
    printValueItems(analysisItems, true);
}

function getAnalysisFlowPoints()
{
    return getFlowPoints(interfazeProcessor);
}

function isAnalysisActive()
{
    return true;
}

function initiateParameterActiveAnalysis(name, value, alternate)
{
    if (shift)
    {
        print(display(name) + " = " + display(value) + " -> " + display(alternate));

        return false;
    }

    if (name != null && value != null)
    {
        print(style("analyze_active") + "Analyzing" + " : " + display(value) + " -> " + display(alternate) + " @ " + display(name) + style(null));
        print("");

        return true;
    }

    return false;
}

function playParameterActive(base, host, request, response, type, name, value, alternate)
{
    var search = value;
    var replace = alternate;

    var color = getColor();
    var note = getIcon();

    var Index = Java.type("fusionlite.model.Index");
    var idx = new Index(-1);

    var activeResponse = play(base, host, request, color, note, type, name, search, replace, idx);
    var index = idx.getIndex();

    var Thread = Java.type("java.lang.Thread");
    Thread.sleep(500);

    return activeResponse;
}

function analyzeParameterActive(name, value, alternate)
{
    extensionProcessor.analyze(alternate, 0, true, true, false, false, false, false);
}

function initiateValueActiveAnalysis(value, alternate)
{
    if (shift)
    {
        print(display(value) + " -> " + display(alternate));

        return false;
    }

    if (value != null)
    {
        print(style("analyze_active") + "Analyzing" + " : " + display(value) + " -> " + display(alternate) + style(null));
        print("");

        return true;
    }

    return false;
}

function playValueActive(base, host, request, response, type, index, length, value, alternate)
{
    var header = request.getHeader();
    var body = request.getBody();

    if (type == "HEADER")
    {
        header = header.substring(0, index) + alternate + header.substring(index + length);
    }
    else
    {
        var String = Java.type("java.lang.String");

        var content = new String(body);

        content = content.substring(0, index) + alternate + content.substring(index + length);

        body = content.getBytes();
    }

    var Request = Java.type("fusionlite.model.Request");
    request = new Request(header, body);

    var color = getColor();
    var note = getIcon();

    var Index = Java.type("fusionlite.model.Index");
    var idx = new Index(-1);

    var activeResponse = play(base, host, request, color, note, null, null, null, null, idx);
    var index = idx.getIndex();

    var Thread = Java.type("java.lang.Thread");
    Thread.sleep(500);

    return activeResponse;
}

function analyzeValueActive(value, alternate)
{
    extensionProcessor.analyze(alternate, 0, true, true, false, false, false, false);
}

function getAnalysisActiveValueItems()
{
    return getValueItems(extensionProcessor, true);
}

function printAnalysisActiveValueItems(analysisActiveItems)
{
    printValueItems(analysisActiveItems, true);
}

function getAnalysisActiveFlowPoints()
{
    return getFlowPoints(extensionProcessor);
}

function printAnalysisDifferentialResponse(analysisResponse, analysisActiveResponse)
{
    if (analysisResponse != null && analysisActiveResponse != null)
    {
        var analysisBody = analysisResponse.getBody();

        var analysisActiveBody = analysisActiveResponse.getBody();

        if (analysisBody != null && analysisActiveBody != null)
        {
            var percentage = (analysisBody.length != 0) ? ((analysisActiveBody.length * 100) / analysisBody.length).toFixed(2) : "--";

            var type = "";
            var symbol = "";

            if (analysisActiveBody.length < analysisBody.length)
            {
                type = "less";
                symbol = "<";
            }
            else if (analysisActiveBody.length > analysisBody.length)
            {
                type = "greater";
                symbol = ">";
            }
            else
            {
                if (arrayEqual(analysisBody, analysisActiveBody))
                {
                    type = "equal";
                    symbol = "=";
                }
                else
                {
                    type = "not_equal";
                    symbol = "!=";
                }
            }

            print(style("response_" + type) + "--------" + " " + "Response" + " " + analysisActiveBody.length + " " + symbol + " " + analysisBody.length + " " + "[" + percentage + "%" + "]" + style(null));

            print("");

            var String = Java.type("java.lang.String");

            var analysisContent = new String(analysisBody);

            var analysisActiveContent = new String(analysisActiveBody);

            var result = compare(analysisContent, analysisActiveContent, 64);

            result = tabs2spaces(result);

            if (result != "")
            {
                print(result);

                print("");
            }
        }
    }
}

function printAnalysisDifferentialPoints(analysisPoints, analysisActivePoints)
{
    if (analysisPoints != null && analysisActivePoints != null)
    {
        var percentage = (analysisPoints.length != 0) ? ((analysisActivePoints.length * 100) / analysisPoints.length).toFixed(2) : "--";

        var type = "";
        var symbol = "";

        if (analysisActivePoints.length < analysisPoints.length)
        {
            type = "less";
            symbol = "<";
        }
        else if (analysisActivePoints.length > analysisPoints.length)
        {
            type = "greater";
            symbol = ">";
        }
        else
        {
            if (arrayEqual(analysisPoints, analysisActivePoints))
            {
                type = "equal";
                symbol = "=";
            }
            else
            {
                type = "not_equal";
                symbol = "!=";
            }
        }

        print(style("points_" + type) + "--------" + " " + "Points" + " " + analysisActivePoints.length + " " + symbol + " " + analysisPoints.length + " " + "[" + percentage + "%" + "]" + style(null));

        print("");

        var diff = arrayDiff(analysisPoints, analysisActivePoints);

        if (diff != -1)
        {
            if (diff > 0)
            {
                var analysisBasicItem = extensionProcessor.getAnalysisBasicItem(true, diff - 1);
                var event = analysisBasicItem.getEvent();
                print(style("diff_before") + "--------" + " " + display(event) + style(null));
            }

            var analysisBasicItem = extensionProcessor.getAnalysisBasicItem(true, diff);
            var event = analysisBasicItem.getEvent();
            print(style("diff_current") + "--------" + " " + display(event) + style(null));

            print("");
        }
    }
}

function play(base, host, request, color, note, type, name, search, replace, idx)
{
    request = session(host, request);

    printRequest(request);

    if (extensionProcessor != null)
    {
        var header = request.getHeader();
        var body = request.getBody();

        var complete = true;
        var sensitive = true;

        extensionProcessor.start(false);

        var response = extensionProcessor.play(base, host, header, body, color, note, complete, sensitive, type, name, search, replace, false, null, -1, idx);

        extensionProcessor.stop(false);

        if (response != null)
        {
            printResponse(response);
        }
        else
        {
            printError();
        }

        return response;
    }

    return null;
}

function getColor()
{
    return 0;
}

function getIcon()
{
    return "\u21AF";
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "analyze"              :   return "\u001B[38;5;77m";
            case "analyze_active"       :   return "\u001B[38;5;202m";
            case "response_less"        :   return "\u001B[38;5;208m";
            case "response_equal"       :   return "\u001B[38;5;77m";
            case "response_not_equal"   :   return "\u001B[38;5;208m";
            case "response_greater"     :   return "\u001B[38;5;208m";
            case "points_less"          :   return "\u001B[38;5;208m";
            case "points_equal"         :   return "\u001B[38;5;77m";
            case "points_not_equal"     :   return "\u001B[38;5;208m";
            case "points_greater"       :   return "\u001B[38;5;208m";
            case "diff_before"          :   return "\u001B[38;5;208m";
            case "diff_current"         :   return "\u001B[38;5;202m";
            case "diff_after"           :   return "\u001B[38;5;208m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
