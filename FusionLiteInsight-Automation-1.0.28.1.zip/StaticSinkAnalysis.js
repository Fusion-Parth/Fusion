print("Static Sink Analysis");

var args = arguments;

function extension()
{
    return false;
}

function start(type)
{
    load(directory + "/" + "Core.js");
    load(directory + "/" + "StaticSink.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            if (structureFile())
            {
                var fileName = "Temp" + ".txt";

                var filePath = "../Temp/" + fileName;

                var PrintStream = Java.type("java.io.PrintStream");

                var printStream = new PrintStream(filePath);

                print = function(value)
                {
                    printStream.println(value);
                }

                structure();

                printStream.close();
            }
            else
            {
                structure();
            }
        }
    }

    return false;
}

function structure()
{
    var categories = sinkCategories();

    for (var i=0; i<categories.length; i++)
    {
        var category = categories[i];

        sink(category);
    }
}

function sink(category)
{
    print(style("category") + "Analyzing" + " " + display(category) + style(null));
    print("");

    var forward = false;

    var reverse = true;

    var structureCallItems = interfazeProcessor.getStructureCallItems();

    var structureLocations = interfazeProcessor.getStructureLocations();

    if (structureCallItems != null && structureLocations != null)
    {
        var nodes = [];

        for (var i=0; i<structureCallItems.length; i++)
        {
            nodes.push(i);

            search(structureCallItems[i], structureLocations, nodes, category, forward, reverse);

            nodes.pop();
        }
    }
}

function search(structureItem, structureLocations, nodes, category, forward, reverse)
{
    match(structureItem, structureLocations, nodes, category, forward, reverse);

    var structureItems = structureItem.getChildren();

    if (structureItems != null)
    {
        for (var i=0; i<structureItems.length; i++)
        {
            nodes.push(i);

            search(structureItems[i], structureLocations, nodes, category, forward, reverse);

            nodes.pop();
        }
    }
}

function match(structureItem, structureLocations, nodes, category, forward, reverse)
{
    var signature = structureItem.getText();

    var structureItems = structureItem.getChildren();

    if (structureItems != null)
    {
        for (var i=0; i<structureItems.length; i++)
        {
            var attribute = structureItems[i].getText();

            if (attribute.startsWith("Sink" + " -> "))
            {
                var type = attribute.substring(("Sink" + " -> ").length);

                if (type == category)
                {
                    var Color = Java.type("fusionlite.model.Color");

                    var color = Color.color(Color.combine(structureItems[i].getColor()));

                    if (sinkSignature(category, color, signature))
                    {
                        analyze(structureItem, structureLocations, nodes, color, forward, reverse);
                    }
                }
            }
        }
    }
}

function analyze(structureItem, structureLocations, nodes, color, forward, reverse)
{
    var signature = structureItem.getText();

    print(style("signature_" + color) + "Analyzing" + " " + display(signature) + style(null));
    print("");

    var structureItems = structureItem.getChildrens();

    if (structureItems != null)
    {
        var indexes = structureItems.getIndexes();

        for (var i=0; i<indexes.length; i++)
        {
            var location = i;

            var index = indexes[i];

            var structureLocation = structureLocations[index];

            var analysisImage = null;

            if (structureDisplay())
            {
                if (structureLocation.indexOf(" : ") != -1)
                {
                    interfazeProcessor.setCodeMode(true);

                    var Thread = Java.type("java.lang.Thread");

                    interfazeProcessor.closeCode(true);

                    Thread.sleep(200);

                    var Signature = Java.type("fusionlite.model.Signature");

                    interfazeProcessor.setCode(structureLocation, Signature.LOCATION);

                    Thread.sleep(800);

                    if (structureImage())
                    {
                        analysisImage = interfazeProcessor.getImage(1);
                    }
                }
            }

            interfazeProcessor.analyze(nodes, location, forward, reverse);

            var analysisItems = interfazeProcessor.getAnalysisItems();

            analysisItems = processStructureItems(analysisItems);

            if (analysisItems != null)
            {
                if (analysisImage != null)
                {
                    var UUID = Java.type("java.util.UUID");

                    var fileName = "Image-" + UUID.randomUUID().toString() + ".png";

                    var filePath = "../Temp/" + fileName;

                    print("#" + fileName + "#");

                    if (structureFile())
                    {
                        var FileOutputStream = Java.type("java.io.FileOutputStream");

                        var fileOutputStream = new FileOutputStream(filePath);

                        fileOutputStream.write(analysisImage);

                        fileOutputStream.close();
                    }
                }

                printStructureLocation(structureLocation);

                printStructureItems(analysisItems);

                if (analysisImage != null)
                {
                    print("#" + "Page" + "#");
                }
            }
        }
    }
}

function processStructureItems(analysisItems)
{
    if (analysisItems != null)
    {
        var structureItems = [];

        for (var i=0; i<analysisItems.length; i++)
        {
            var analysisItem = analysisItems[i];

            analysisItem = processStructureItem(analysisItem);

            if (analysisItem != null)
            {
                structureItems.push(analysisItem);
            }
        }

        if (structureItems.length != 0)
        {
            return structureItems;
        }

        return null;
    }

    return null;
}

function processStructureItem(analysisItem)
{
    var category = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    category = sinkProcess(category, color, analysisItem);

    if (category != null)
    {
        analysisItem.setText(category);

        return analysisItem;
    }

    return null;
}

function trimItem(item)
{
    var HashSet = Java.type("java.util.HashSet");

    var set = new HashSet();

    var children = item.children;

    if (children != null && !isLeaf(item))
    {
        var ArrayList = Java.type("java.util.ArrayList");

        var list = new ArrayList();

        for (var i=0; i<children.length; i++)
        {
            var child = children[i];

            var duplicate = compactItem(child, set);

            if (!duplicate)
            {
                list.add(child);
            }
        }

        var ItemArray = Java.type("fusionlite.model.Analysis.AdvancedItem[]");

        children = list.toArray(new ItemArray(0));

        item.children = children;

        if (children.length != 0)
        {
        }
    }
}

function compactItem(item, set)
{
    var children = item.children;

    if (children != null && !isLeaf(item))
    {
        var ArrayList = Java.type("java.util.ArrayList");

        var list = new ArrayList();

        for (var i=0; i<children.length; i++)
        {
            var child = children[i];

            var duplicate = compactItem(child, set);

            if (!duplicate)
            {
                list.add(child);
            }
        }

        var ItemArray = Java.type("fusionlite.model.Analysis.AdvancedItem[]");

        children = list.toArray(new ItemArray(0));

        item.children = children;

        if (children.length != 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return isTrim(item, set);
    }
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "category"             :   return "\u001B[38;5;141m";
            case "signature_green"      :   return "\u001B[38;5;77m";
            case "signature_orange"     :   return "\u001B[38;5;208m";
            case "signature_red"        :   return "\u001B[38;5;196m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
