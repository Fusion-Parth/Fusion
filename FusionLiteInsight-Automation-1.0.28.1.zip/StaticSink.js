function printStructureLocation(location)
{
    var text = "Location" + " " + location;

    print(style_static("location") + display(text) + style_static(null));
}

function printStructureItems(analysisItems)
{
    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureItem(analysisItems[i], 0, null);
        }

        print("");
    }
}

function printStructureItem(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("category_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureNode(analysisItems[i], depth + 1, analysisItem);
        }
    }
}

function printStructureNodes(analysisItem, depth, analysisBase)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureNode(analysisItems[i], depth, analysisItem);
        }
    }
}

function printStructureNode(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    if (text.startsWith("Sink" + " "))
    {
        printStructureDynamic(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Transform" + " "))
    {
        printStructureDynamic(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Indirect" + " "))
    {
        printStructureDynamic(analysisItem, depth, analysisBase);
    }
    else if (text == "Track")
    {
        printStructureTrack(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Constant" + " "))
    {
        printStructureConstant(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Source" + " "))
    {
        printStructureSource(analysisItem, depth, analysisBase);
    }
    else if (text == "Unknown" || text.startsWith("Unknown" + " "))
    {
        printStructureUnknown(analysisItem, depth, analysisBase);
    }
    else if (text == "Composite")
    {
        printStructureComposite(analysisItem, depth, analysisBase);
    }
    else if (text == "Tracked")
    {
        printStructureTracked(analysisItem, depth, analysisBase);
    }
    else if (text == "Tracking")
    {
        printStructureTracking(analysisItem, depth, analysisBase);
    }
    else if (text == "Untracked" || text.startsWith("Untracked" + " "))
    {
        printStructureUntracked(analysisItem, depth, analysisBase);
    }
    else if (text == "Converged")
    {
        printStructureConverged(analysisItem, depth, analysisBase);
    }
    else if (text == "Completed")
    {
        printStructureCompleted(analysisItem, depth, analysisBase);
    }
    else
    {
        printStructureNodes(analysisItem, depth, analysisBase);
    }
}

function printStructureDynamic(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Sink" + " "))
    {
        signature = text.substring(("Sink" + " ").length);
    }
    else if (text.startsWith("Transform" + " "))
    {
        signature = text.substring(("Transform" + " ").length);
    }
    else if (text.startsWith("Indirect" + " "))
    {
        signature = text.substring(("Indirect" + " ").length);
    }
    else
        return;

    var index1 = signature.indexOf(") [");

    if (index1 != -1)
        index1 = (index1 + (") [").length) - 1;

    var index2 = signature.lastIndexOf("]");

    if (index2 != -1)
        index2 = (index2 - ("]").length) + 1;

    if ((index1 != -1 && index2 != -1) && (index1 < index2))
    {
        text = signature.substring(index1 + 1, index2);

        print(pad(depth) + style_static("constant") + display(text) + style_static(null));

        printStructureNodes(analysisItem, depth, analysisBase);
    }
    else
    {
        printStructureNodes(analysisItem, depth, analysisBase);
    }
}

function printStructureTrack(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("track") + display(text) + style_static(null));

    printStructureNodes(analysisItem, depth + 1, analysisBase);
}

function printStructureConstant(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var value = text.substring(("Constant" + " ").length);

    text = "\"" + value + "\"";

    print(pad(depth) + style_static("constant") + display(text) + style_static(null));
}

function printStructureSource(analysisItem, depth, analysisBase)
{
    var type = analysisBase.getText();

    var text = analysisItem.getText();

    var signature = text.substring(("Source" + " ").length);

    text = "[" + type + " " + signature + "]";

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("source_" + color) + display(text) + style_static(null));
}

function printStructureUnknown(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Unknown" + " "))
    {
        signature = text.substring(("Unknown" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    print(pad(depth) + style_static("unknown") + display(text) + style_static(null));
}

function printStructureComposite(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("composite") + display(text) + style_static(null));
}

function printStructureTracked(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("tracked") + display(text) + style_static(null));
}

function printStructureTracking(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("tracking") + display(text) + style_static(null));
}

function printStructureUntracked(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var signature = null;

    if (text.startsWith("Untracked" + " "))
    {
        signature = text.substring(("Untracked" + " ").length);
    }

    text = "..." + ((signature != null) ? " " + signature : "");

    print(pad(depth) + style_static("untracked") + display(text) + style_static(null));
}

function printStructureConverged(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("converged") + display(text) + style_static(null));
}

function printStructureCompleted(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    text = "...";

    print(pad(depth) + style_static("completed") + display(text) + style_static(null));
}

function isLeaf(item)
{
    var text = item.text;

    if (text.startsWith("Source" + " "))
    {
        return true;
    }
    else
    {
        return false;
    }
}

function isTrim(item, set)
{
    var text = item.text;

    var key = text;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(item.color));

    if (text.startsWith("Source" + " "))
    {
        return false;
    }
    else if (text.startsWith("Constant" + " ") || text.startsWith("Untracked" + " "))
    {
        if (!set.contains(key))
        {
            set.add(key);

            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return true;
    }
}

function style_static(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "location"         :   return "\u001B[38;5;38m";
            case "category_green"   :   return "\u001B[38;5;77m";
            case "category_orange"  :   return "\u001B[38;5;208m";
            case "category_red"     :   return "\u001B[38;5;196m";
            case "track"            :   return "\u001B[38;5;73m";
            case "constant"         :   return "\u001B[38;5;77m";
            case "source_green"     :   return "\u001B[38;5;77m";
            case "source_orange"    :   return "\u001B[38;5;202m";
            case "source_red"       :   return "\u001B[38;5;196m";
            case "unknown"          :   return "\u001B[38;5;208m";
            case "composite"        :   return "\u001B[38;5;77m";
            case "tracked"          :   return "\u001B[38;5;73m";
            case "tracking"         :   return "\u001B[38;5;73m";
            case "untracked"        :   return "\u001B[38;5;208m";
            case "converged"        :   return "\u001B[38;5;73m";
            case "completed"        :   return "\u001B[38;5;77m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
