function printStructureLocation(location)
{
    var text = "Location" + " " + location;

    print(style_static("location") + display(text) + style_static(null));
}

function printStructureItems(analysisItems)
{
    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureItem(analysisItems[i], 0, null);
        }

        print("");
    }
}

function printStructureItem(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("category_" + color) + display(text) + style_static(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureNode(analysisItems[i], depth + 1, analysisItem);
        }
    }
}

function printStructureNodes(analysisItem, depth, analysisBase)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printStructureNode(analysisItems[i], depth, analysisItem);
        }
    }
}

function printStructureNode(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    if (text.startsWith("Constant" + " "))
    {
        printStructureConstant(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Sink" + " "))
    {
        printStructureSink(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Unknown" + " "))
    {
        printStructureUnknown(analysisItem, depth, analysisBase);
    }
    else if (text.startsWith("Untracked" + " "))
    {
        printStructureUntracked(analysisItem, depth, analysisBase);
    }
    else
    {
        printStructureNodes(analysisItem, depth, analysisBase);
    }
}

function printStructureConstant(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var value = text.substring(("Constant" + " ").length);

    var location = getLocation(analysisItem.getData());

    text = "\"" + value + "\"";

    if (false)
    {
        print(pad(depth) + style_static("constant") + display(text) + style_static(null) + " @ " + style_static("location") + display(location) + style_static(null));
    }
}

function printStructureSink(analysisItem, depth, analysisBase)
{
    var type = analysisBase.getText();

    var text = analysisItem.getText();

    var signature = text.substring(("Sink" + " ").length);

    var location = getLocation(analysisItem.getData());

    text = type + " " + signature;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    print(pad(depth) + style_static("sink_" + color) + display(text) + style_static(null) + " @ " + style_static("location") + display(location) + style_static(null));
}

function printStructureUnknown(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Unknown" + " ").length);

    var location = getLocation(analysisItem.getData());

    var index1 = signature.indexOf("[");

    var index2 = signature.lastIndexOf("]");

    if ((index1 != -1 && index2 != -1) && (index1 < index2))
    {
        signature = signature.substring(index1 + 1, index2);
    }

    text = "Unknown" + " " + signature;

    if (false)
    {
        print(pad(depth) + style_static("unknown") + display(text) + style_static(null) + " @ " + style_static("location") + display(location) + style_static(null));
    }
}

function printStructureUntracked(analysisItem, depth, analysisBase)
{
    var text = analysisItem.getText();

    var signature = text.substring(("Untracked" + " ").length);

    var location = getLocation(analysisItem.getData());

    var index1 = signature.indexOf("[");

    var index2 = signature.lastIndexOf("]");

    if ((index1 != -1 && index2 != -1) && (index1 < index2))
    {
        signature = signature.substring(index1 + 1, index2);
    }

    text = signature;

    if (text.startsWith("Parameter" + " "))
    {
        print(pad(depth) + style_static("untracked") + display(text) + style_static(null) + " @ " + style_static("location") + display(location) + style_static(null));
    }
}

function getLocation(location)
{
    if (location.startsWith("Execute Static" + " "))
    {
        location = location.substring(("Execute Static" + " ").length);
    }
    else if (location.startsWith("Execute Instance" + " "))
    {
        location = location.substring(("Execute Instance" + " ").length);
    }

    return location;
}

function isLeaf(item)
{
    var text = item.text;

    if (text.startsWith("Sink" + " "))
    {
        return true;
    }
    else
    {
        return false;
    }
}

function isTrim(item, set)
{
    var text = item.text;

    var key = text;

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(item.color));

    if (text.startsWith("Sink" + " "))
    {
        return false;
    }
    else if (text.startsWith("Constant" + " ") || text.startsWith("Untracked" + " "))
    {
        if (!set.contains(key))
        {
            set.add(key);

            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return true;
    }
}

function style_static(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "location"         :   return "\u001B[38;5;38m";
            case "category_green"   :   return "\u001B[38;5;77m";
            case "category_orange"  :   return "\u001B[38;5;208m";
            case "category_red"     :   return "\u001B[38;5;196m";
            case "track"            :   return "\u001B[38;5;73m";
            case "constant"         :   return "\u001B[38;5;77m";
            case "sink_green"       :   return "\u001B[38;5;77m";
            case "sink_orange"      :   return "\u001B[38;5;202m";
            case "sink_red"         :   return "\u001B[38;5;196m";
            case "unknown"          :   return "\u001B[38;5;208m";
            case "composite"        :   return "\u001B[38;5;77m";
            case "tracked"          :   return "\u001B[38;5;73m";
            case "tracking"         :   return "\u001B[38;5;73m";
            case "untracked"        :   return "\u001B[38;5;208m";
            case "converged"        :   return "\u001B[38;5;73m";
            case "completed"        :   return "\u001B[38;5;77m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
