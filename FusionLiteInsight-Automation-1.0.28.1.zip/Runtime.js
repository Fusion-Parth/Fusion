function analyzeFlowItems(processor)
{
    if (processor.isAnalysisBasic())
    {
        var size = processor.getAnalysisBasicSize(true);

        if (size != -1)
        {
            var BLOCK_SIZE = 0x2000;

            var off = 0;

            while (true)
            {
                var len = size - off;

                if (len == 0)
                    break;

                if (len > BLOCK_SIZE)
                    len = BLOCK_SIZE;

                var basicItems = processor.getAnalysisBasicItems(true, off, len);

                for (var i=0; i<len; i++)
                {
                    analyzeFlowItem(processor, off + i, basicItems[i]);
                }

                off += len;
            }
        }
    }
}

function getFlowPoints(processor)
{
    if (processor.isAnalysisBasic())
    {
        var size = processor.getAnalysisBasicSize(true);

        if (size != -1)
        {
            var flowPoints = new Array(size);

            var BLOCK_SIZE = 0x2000;

            var off = 0;

            while (true)
            {
                var len = size - off;

                if (len == 0)
                    break;

                if (len > BLOCK_SIZE)
                    len = BLOCK_SIZE;

                var basicPoints = processor.getAnalysisBasicPoints(true, off, len);

                for (var i=0; i<len; i++)
                {
                    flowPoints[off + i] = basicPoints[i];
                }

                off += len;
            }

            return flowPoints;
        }
    }

    return null;
}

function getValueItems(processor, points)
{
    if (processor.isAnalysisValue())
    {
        return processor.getAnalysisValueItems(points);
    }

    return null;
}

function printValueItems(analysisItems, points)
{
    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printValueItem(analysisItems[i], 0, points);
        }

        print("");
    }
}

function printValueItem(analysisItem, depth, points)
{
    var point = analysisItem.getPoint();

    var text = analysisItem.getText();

    if (points)
        print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth) + style_runtime("value") + display(text) + style_runtime(null));
    else
        print(pad(depth) + style_runtime("value") + display(text) + style_runtime(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printValueNode(analysisItems[i], depth + 1, points);
        }
    }
}

function printValueNodes(analysisItem, depth, points)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printValueNode(analysisItems[i], depth, points);
        }
    }
}

function printValueNode(analysisItem, depth, points)
{
    var text = analysisItem.getText();

    if (text.startsWith("SOURCE" + " "))
    {
        printValueSource(analysisItem, depth, points);
    }
    else if (text.startsWith("FX" + " "))
    {
        printValueTransform(analysisItem, depth, points);
    }
    else if (text.startsWith("CALL" + " "))
    {
        printValueCall(analysisItem, depth, points);
    }
    else if (text == "Element -> Array")
    {
        printValueNodes(analysisItem, depth, points);
    }
    else if (text == "Array -> Element")
    {
        printValueNodes(analysisItem, depth, points);
    }
    else
    {
        var idx = text.indexOf(" ");

        if (idx != -1)
        {
            var str = text.substring(0, idx);

            if (isValueCategory(str))
            {
                printValueSink(analysisItem, depth, points);
            }
        }
    }
}

function isValueCategory(str)
{
    for (var i=0; i<str.length; i++)
    {
        var character = str.charAt(i);

        if (character != character.toUpperCase())
        {
            return false;
        }
    }

    return true;
}

function printValueSource(analysisItem, depth, points)
{
    var point = analysisItem.getPoint();

    var text = analysisItem.getText();

    var str = text.substring(("SOURCE" + " ").length);

    var type = "";

    var signature = "";

    if (str == "Static")
    {
        type = "Static";
    }
    else if (str.startsWith("Static" + " "))
    {
        type = "Static";

        signature = str.substring(("Static" + " ").length);
    }
    else if (str == "Instance")
    {
        type = "Instance";
    }
    else if (str.startsWith("Instance" + " "))
    {
        type = "Instance";

        signature = str.substring(("Instance" + " ").length);
    }
    else if (str == "Element")
    {
        type = "Element";
    }
    else if (str.startsWith("Element" + " "))
    {
        type = "Element";

        signature = str.substring(("Element" + " ").length);
    }
    else if (str == "Return")
    {
        type = "Return";
    }
    else if (str.startsWith("Return" + " "))
    {
        type = "Return";

        signature = str.substring(("Return" + " ").length);
    }
    else
    {
        signature = str;
    }

    var component = "";

    var func = "";

    var index = signature.indexOf(" : ");

    if (index != -1)
    {
        component = signature.substring(0, index);

        func = signature.substring(index + (" : ").length);
    }
    else
    {
        func = signature;
    }

    var filter = isValueFilter(type, component, func, signature, analysisItem);

    if (filter)
    {
        return;
    }

    text = "SOURCE";

    if (type != "")
    {
        text = text + " " + type;
    }

    if (signature != "")
    {
        text = text + " " + signature;
    }

    if (points)
        print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth) + style_runtime("source") + display(text) + style_runtime(null));
    else
        print(pad(depth) + style_runtime("source") + display(text) + style_runtime(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            printValueNode(analysisItems[i], depth + 1, points);
        }
    }
}

function isValueFilter(type, component, func, signature, analysisItem)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var text = analysisItems[i].getText();

            if (text != "Untracked")
            {
                return false;
            }
        }
    }

    return true;
}

function printValueTransform(analysisItem, depth, points)
{
    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " ") || attribute.startsWith("Return" + " "))
            {
                printValueNodes(analysisItems[i], depth, points);
            }
        }
    }
}

function printValueCall(analysisItem, depth, points)
{
    var point = analysisItem.getPoint();

    var text = analysisItem.getText();

    var signature = text.substring(("CALL" + " ").length);

    var component = "";

    var func = "";

    var index = signature.indexOf(" : ");

    if (index != -1)
    {
        component = signature.substring(0, index);

        func = signature.substring(index + (" : ").length);
    }
    else
    {
        func = signature;
    }

    var category = categorizeValueCall(component, func, signature, analysisItem);

    if (category == "")
    {
        return;
    }

    text = category;

    if (signature != "")
    {
        text = text + " " + signature;
    }

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    if (points)
        print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth) + style_runtime("call_" + color) + display(text) + style_runtime(null));
    else
        print(pad(depth) + style_runtime("call_" + color) + display(text) + style_runtime(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Arguments" + " "))
            {
                if (points)
                    print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth + 1) + style_runtime("attribute") + display(attribute) + style_runtime(null));
                else
                    print(pad(depth + 1) + style_runtime("attribute") + display(attribute) + style_runtime(null));
            }
        }
    }
}

function printValueSink(analysisItem, depth, points)
{
    var point = analysisItem.getPoint();

    var text = analysisItem.getText();

    var idx = text.indexOf(" ");

    var category = text.substring(0, idx);

    var signature = text.substring(idx + (" ").length);

    var component = "";

    var func = "";

    var index = signature.indexOf(" : ");

    if (index != -1)
    {
        component = signature.substring(0, index);

        func = signature.substring(index + (" : ").length);
    }
    else
    {
        func = signature;
    }

    text = category;

    if (signature != "")
    {
        text = text + " " + signature;
    }

    var Color = Java.type("fusionlite.model.Color");

    var color = Color.color(Color.combine(analysisItem.getColor()));

    if (points)
        print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth) + style_runtime("sink_" + color) + display(text) + style_runtime(null));
    else
        print(pad(depth) + style_runtime("sink_" + color) + display(text) + style_runtime(null));

    var analysisItems = analysisItem.getChildren();

    if (analysisItems != null)
    {
        for (var i=0; i<analysisItems.length; i++)
        {
            var attribute = analysisItems[i].getText();

            if (attribute.startsWith("Type" + " ") || attribute.startsWith("Object" + " ") || attribute.startsWith("Parameter" + " "))
            {
                if (points)
                    print(style_runtime("hex") + hex(point) + style_runtime(null) + " " + pad(depth + 1) + style_runtime("attribute") + display(attribute) + style_runtime(null));
                else
                    print(pad(depth + 1) + style_runtime("attribute") + display(attribute) + style_runtime(null));
            }
        }
    }
}

function hex(point)
{
    if (point != -1)
    {
        var hex = point.toString(16);

        var length = (8 - hex.length);

        var padding = "";
        for (var i=0; i<length; i++)
            padding = padding + "0";

        return padding + hex;
    }

    return "--------";
}

function style_runtime(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "hex"              :   return "\u001B[38;5;103m";
            case "value"            :   return "\u001B[38;5;196m";
            case "source"           :   return "\u001B[38;5;208m";
            case "call_green"       :   return "\u001B[38;5;77m";
            case "call_orange"      :   return "\u001B[38;5;214m";
            case "call_red"         :   return "\u001B[38;5;196m";
            case "sink_green"       :   return "\u001B[38;5;77m";
            case "sink_orange"      :   return "\u001B[38;5;202m";
            case "sink_red"         :   return "\u001B[38;5;196m";
            case "attribute"        :   return "\u001B[38;5;73m";
            default                 :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}
