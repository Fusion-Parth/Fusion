print("Value Analysis");

function extension()
{
    return false;
}

function start(type)
{
    if (type != "Function")
    {
        return false;
    }

    load(directory + "/" + "Core.js");
    load(directory + "/" + "Dynamic.js");
    load(directory + "/" + "Runtime.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            return true;
        }
    }

    return false;
}

function delay()
{
    return 100;
}

var printStream = null;

function functions_preprocess()
{
    if (valueFile())
    {
        var fileName = "Temp" + ".txt";

        var filePath = "../Temp/" + fileName;

        var PrintStream = Java.type("java.io.PrintStream");

        printStream = new PrintStream(filePath);

        print = function(value)
        {
            printStream.println(value);
        }
    }
    else
    {
        printStream = null;
    }

    var category = "VALUES";

    print(style("category") + "Analyzing" + " " + display(category) + style(null));
    print("");
}

function function_process(fx, fxIndex)
{
    if ((valueTrace() & 1) != 0)
    {
        print(style("function") + "Analyzing" + " : " + display(fx.getName()) + style(null));
        print("");
    }
}

function function_node_process(fx, fxIndex, fxNode, fxNodeIndex)
{
    if ((valueTrace() & 2) != 0)
    {
        print(style("function_node") + "Analyzing" + " : " + display(fx.getName() + " > " + (fxNodeIndex + 1)) + style(null));
        print("");
    }
}

function function_data_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    if ((valueTrace() & 4) != 0)
    {
        print(style("function_data") + "Analyzing" + " : " + display(fx.getName() + " > " + (fxNodeIndex + 1) + " > " + (fxDataIndex + 1)) + style(null));
        print("");
    }
}

function function_data_drive_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    var nodeValue = fxNode.getDescription();

    var dataValue = fxData.getDescription();

    analyze(nodeValue, dataValue);
}

function analyze(nodeValue, dataValue)
{
    var analysisImage = null;

    if (valueImage())
    {
        analysisImage = interfazeProcessor.getImage(1);
    }

    if (analysisImage != null)
    {
        var UUID = Java.type("java.util.UUID");

        var fileName = "Image-" + UUID.randomUUID().toString() + ".png";

        var filePath = "../Temp/" + fileName;

        print("#" + fileName + "#");

        if (valueFile())
        {
            var FileOutputStream = Java.type("java.io.FileOutputStream");

            var fileOutputStream = new FileOutputStream(filePath);

            fileOutputStream.write(analysisImage);

            fileOutputStream.close();
        }
    }

    var begin = interfazeProcessor.getBegin();

    var end = interfazeProcessor.getEnd();

    for (var index=begin; index<end; index++)
    {
        analyzeCommunication(index);
    }

    var array = nodeValue.split("\r\n");

    for (var i=0; i<array.length; i++)
    {
        var value = array[i];

        if (value != "")
        {
            analyzeCustom(value);
        }
    }

    var array = dataValue.split("\r\n");

    for (var i=0; i<array.length; i++)
    {
        var value = array[i];

        if (value != "")
        {
            analyzeCustom(value);
        }
    }

    if (analysisImage != null)
    {
        print("#" + "Page" + "#");
    }
}

function analyzeCommunication(index)
{
    var communication = interfazeProcessor.getCommunication(index);

    if (isCommunicationAnalyzable(index, communication))
    {
        var base = communication.getRef();

        var host = communication.getHost();

        var request = communication.getRequest();

        var response = communication.getResponse();

        if (request != null)
        {
            var header = request.getHeader();
            var body = request.getBody();

            analyzeHeaders(index, base, host, request, response);

            if (body != null)
            {
                analyzeContents(index, base, host, request, response);
            }
        }
    }
}

function initiateParameterAnalysis(name, value)
{
    if (shift)
    {
        print(display(name) + " = " + display(value));

        return false;
    }

    if (name != null && value != null)
    {
        print(style("analyze_parameter") + "Analyzing" + " : " + display(value) + " @ " + display(name) + style(null));
        print("");

        if (interfazeProcessor.isRuntime())
        {
            return true;
        }
    }

    return false;
}

function analyzeParameter(name, value)
{
    interfazeProcessor.analyze(value, 0, false, true, false, false, false, false);
}

function initiateValueAnalysis(value)
{
    if (shift)
    {
        print(display(value));

        return false;
    }

    if (value != null)
    {
        print(style("analyze_value") + "Analyzing" + " : " + display(value) + style(null));
        print("");

        if (interfazeProcessor.isRuntime())
        {
            return true;
        }
    }

    return false;
}

function analyzeValue(value)
{
    interfazeProcessor.analyze(value, 0, false, true, false, false, false, false);
}

function getAnalysisValueItems()
{
    return getValueItems(interfazeProcessor, false);
}

function printAnalysisValueItems(analysisItems)
{
    printValueItems(analysisItems, false);
}

function getAnalysisFlowPoints()
{
    return null;
}

function isAnalysisActive()
{
    return false;
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "category"             :   return "\u001B[38;5;141m";
            case "function"             :   return "\u001B[38;5;141m";
            case "function_node"        :   return "\u001B[38;5;141m";
            case "function_data"        :   return "\u001B[38;5;141m";
            case "analyze_parameter"    :   return "\u001B[38;5;77m";
            case "analyze_value"        :   return "\u001B[38;5;77m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}

function functions_postprocess()
{
    if (printStream != null)
    {
        printStream.close();
    }
}
