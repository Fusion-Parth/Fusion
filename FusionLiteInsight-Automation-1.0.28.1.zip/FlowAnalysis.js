print("Flow Analysis");

function extension()
{
    return false;
}

function start(type)
{
    if (type != "Function")
    {
        return false;
    }

    load(directory + "/" + "Core.js");
    load(directory + "/" + "Runtime.js");

    if (interfazeProcessor.isProject())
    {
        var project = interfazeProcessor.getProject();

        if (project.endsWith(".ifla"))
        {
            project = project.substring(0, project.length - ".ifla".length) + ".js";

            load(project);

            return true;
        }
    }

    return false;
}

function delay()
{
    return 100;
}

function functions_preprocess()
{
    print("Function PreProcess");
}

function function_process(fx, fxIndex)
{
    print("Function Process" + " : " + fx.getName());
}

function function_node_process(fx, fxIndex, fxNode, fxNodeIndex)
{
    print("Function Node Process" + " : " + fx.getName() + " > " + (fxNodeIndex + 1));
}

function function_data_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    print("Function Data Process" + " : " + fx.getName() + " > " + (fxNodeIndex + 1) + " > " + (fxDataIndex + 1));
}

function function_data_drive_process(fx, fxIndex, fxNode, fxNodeIndex, fxData, fxDataIndex)
{
    analyze();
}

function analyze()
{
    analyzeFlowItems(interfazeProcessor);
}

function analyzeFlowItem(processor, index, item)
{
    var type = item.getType();

    var event = item.getEvent();

    processFlowItem(type, event);
}

function printFlowItem(color, type, event)
{
    var TYPE_CHARS = 8;

    print(style("item_" + color) + type + space(TYPE_CHARS - type.length) + " " + display(event) + style(null));
}

function style(type)
{
    if (type != null)
    {
        switch (type)
        {
            case "item_green"           :   return "\u001B[38;5;77m";
            case "item_orange"          :   return "\u001B[38;5;208m";
            case "item_red"             :   return "\u001B[38;5;196m";
            default                     :   return "\u001B[0m";
        }
    }
    else
        return "\u001B[0m";
}

function functions_postprocess()
{
    print("Function PostProcess");
}
