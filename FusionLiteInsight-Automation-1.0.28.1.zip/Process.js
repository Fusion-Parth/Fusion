var Paths = Java.type("java.nio.file.Paths");

var Files = Java.type("java.nio.file.Files");

var String = Java.type("java.lang.String");

var text = new String(Files.readAllBytes(Paths.get("../Temp/Temp.html")));

text = text.replaceAll("<title>Temp\.txt</title>", "<title>Temp</title>");

text = text.replaceAll("#Image-", "<img src=\"Image-");

text = text.replaceAll("\.png#", ".png\"/>");

text = text.replaceAll("<pre>Opening \\S*\\Data\r\n", "<pre>");

text = text.replaceAll("Closing \\S*\\Data\r\n</pre>", "</pre>");

text = text.replaceAll("<pre>\\S* Analysis\r\n", "<pre>");

text = text.replaceAll("<style type=\"text/css\">\r\n", "<style type=\"text/css\">\r\nbody {\r\n  color: #ABB2BF;\r\n  background-color: #282C34;\r\n}\r\n\r\nimg {\r\n  width: 100%;\r\n  height: 100%;\r\n  margin-top: -5px;\r\n  margin-bottom: 0px;\r\n}\r\n\r\n");

text = text.replaceAll("#Page#\r\n</pre>", "</pre>");

text = text.replaceAll("#Page#", "<div style=\"page-break-after: always\"></div>");

Files.write(Paths.get("../Temp/Temp.html"), text.getBytes());
